package com.example.Enum;

public enum PaymentStatus {
	PAYMENTSUCCESSFUL,PAYMENTFAILED

}
