package com.example.Enum;

public enum JobType {
	
	Experienced,Internship

}
